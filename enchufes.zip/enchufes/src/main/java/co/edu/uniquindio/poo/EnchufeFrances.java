package co.edu.uniquindio.poo;

//La clase EnchufeFrances implementa la interfaz EnchufeEuropeo y proporciona una implementación para el método conectar().
public class EnchufeFrances implements EnchufeEuropeo {

    @Override
    public void conectar() {
        System.out.println("Enchufe frances conectado");
        
    }
    
    
}
