package co.edu.uniquindio.poo;

//La clase App crea instancias de EnchufeAleman, EnchufeFrances y AdaptadorEnchufeEuropeoAmericano. Luego, llama al método conectarConTierra() del adaptador para cada tipo de enchufe europeo.
public class App {
    public static void main(String[] args) {
        EnchufeAleman enchufeAleman = new EnchufeAleman();
    AdaptadorEnchufes adaptador = new AdaptadorEnchufes (enchufeAleman);
    adaptador.conectarConTierra();

    EnchufeFrances enchufeFrances = new EnchufeFrances();
    adaptador = new AdaptadorEnchufes(enchufeFrances);
    adaptador.conectarConTierra();
  }
}
    
//En conclusion El adaptador AdaptadorEnchufes permite que un objeto EnchufeEuropeo se use con un objeto EnchufeAmericano, El adaptador convierte la forma y el tamaño del enchufe europeo para que coincidan con las del enchufe americano,Este es un ejemplo simple de cómo se puede usar el patrón Adapter en Java