package co.edu.uniquindio.poo;

public class AdaptadorEnchufes {
    private EnchufeEuropeo enchufeEuropeo;
    //Esta clase tiene un constructor que toma un objeto EnchufeEuropeo como argumento.
    public AdaptadorEnchufes(EnchufeEuropeo enchufeEuropeo) {
        this.enchufeEuropeo = enchufeEuropeo;
    }
    //Este método primero imprime un mensaje que indica que se está adaptando el enchufe europeo. Luego, llama al método conectar() del objeto EnchufeEuropeo. Finalmente, imprime un mensaje que indica que el enchufe europeo se ha conectado al enchufe americano con tierra.
    public void conectarConTierra() {
        System.out.println("Adaptando enchufe europeo...");
        enchufeEuropeo.conectar();
        System.out.println("Enchufe europeo conectado a enchufe americano con tierra.");
      }
    }
