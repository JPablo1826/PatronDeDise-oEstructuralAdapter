package co.edu.uniquindio.poo;

//La interfaz EnchufeEuropeo define un método conectar().
public interface EnchufeEuropeo {
    void conectar();
    
}
