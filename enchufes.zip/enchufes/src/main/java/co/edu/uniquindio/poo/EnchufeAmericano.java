package co.edu.uniquindio.poo;

//La interfaz EnchufeAmericano define un método conectarConTierra().
public interface EnchufeAmericano {
    void conectarConTierra();
    
}
