package co.edu.uniquindio.poo;

//La clase EnchufeAleman implementa la interfaz EnchufeEuropeo y proporciona una implementación para el método conectar().
public class EnchufeAleman implements EnchufeEuropeo{

    @Override
    public void conectar() {
       System.out.println("Enchufe aleman conectado");
        
    }
}
