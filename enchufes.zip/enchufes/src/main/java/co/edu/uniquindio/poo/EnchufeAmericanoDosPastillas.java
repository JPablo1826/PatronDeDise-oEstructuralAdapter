package co.edu.uniquindio.poo;

//La clase EnchufeAmericanoDosPatillas implementa la interfaz EnchufeAmericano y proporciona una implementación para el método conectarConTierra().
public class EnchufeAmericanoDosPastillas implements EnchufeAmericano{

    @Override
    public void conectarConTierra() {
        System.out.println("Enchufe americano de dos pastillas conectado con tierra");
        
    }
    
}
